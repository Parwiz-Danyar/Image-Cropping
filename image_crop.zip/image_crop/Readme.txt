This plugin is developed by Parwiz Danyar for more details contact:
+93795074246
parwizdanyar@gmail.com